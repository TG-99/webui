#!/bin/bash
while :
do
filebrowser -p 8082 -c /etc/filebrowser/filebrowser.json
done
